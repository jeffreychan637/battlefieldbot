/* ========================================
 *
 * The following firmware was developed by Cypress Semiconductor
 * This work is licensed under a Creative Commons Attribution 3.0 Unported License.
 * 
 * http://creativecommons.org/licenses/by/3.0/deed.en_US
 * 
 * You are free to:
 * -To Share — to copy, distribute and transmit the work 
 * -To Remix — to adapt the work 
 * -To make commercial use of the work
 *
 * ========================================
 */
/* CY8CKIT-042 PSoC 4 3-axis I2C Accelerometer Demo - Light Painting and UART 
 * By MAXK
 * Version **
 * Updated 6/27/2013
 *
 * Demonstrates communication with a freescale I2C 3-axis accelerometer. Reads
 * X, Y, and Z acceleration, filters them slightly, and prints them to a UART
 * and the RGB LEDs. Holding down SW2 causes the LED to go black, which is
 * useful in light-painting applications.
 *
 * Hardware configuration:
 * Plug the Sparkfun triple-axis accelerometer breakout board into J3, pins 1-6.
 *  GND should be at pin 1! If you plug it in backwards, it might die!
 *  The kit may be purchased here: https://www.sparkfun.com/products/10955
 * Connect J3 pin 9 to J11 pin 9. 
 *  This connects the UART TX pin to the USB-UART bridge.
 * Configure the board for 5V operation using J9. This will make the LEDs 
 *  brighter for light-painting.
 *
 */
 
#include <device.h>
#include <LED_RGB.h>

//I2C Constants
#define I2C_ACK             0x00
#define I2C_NACK            0xff
#define I2C_WRITE           0x00
#define I2C_READ            0xff

//accelerometer I2C address
#define ACCEL_I2C_ADDR      0x1D

//accelerometer register addresses
#define ACCEL_STATUS_REG    0x00
#define ACCEL_SYSMOD_REG    0x0B
#define ACCEL_XYZ_DATA_CFG  0x0E
#define ACCEL_CTRL_REG1     0x2A

//accelerometer configuration codes
#define ACCEL_MODE_STANDBY  0x00
#define ACCEL_MODE_WAKE     0x01
#define ACCEL_MODE_SLEEP    0x02
#define ACCEL_CTRL_REG_MODE 0x01
#define ACCEL_SCALE_2G      0x00
#define ACCEL_SCALE_4G      0x01
#define ACCEL_SCALE_8G      0x02

/* Absolute value function */
uint16 abs16(int16 input)
{
    uint16 retval;
    
    if(input>=0)
    {
        retval = (uint16) input;
    }
    else
    {
        retval = (uint16) (-input);
    }
    return retval;
}

void main()
{
    uint8 I2C_Status;

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    /* Start the components */
    LED_RGB_Start();
    LED_RGB_SetResolutionBits(15);
    I2C_Accel_Start();
    UART_Debug_Start();
    
    /* Send "initial" character over UART to indicate startup */
    UART_Debug_UartPutCRLF('I');
    
    /* Wait 2ms for accelerometer to startup */
    CyDelay(2);

    /* Perform 1 time configuration of the Accelerometer */
    /* Put the accelerometer in standby mode so we can configure it */
    I2C_Status = I2C_Accel_I2CMasterSendStart(ACCEL_I2C_ADDR, I2C_WRITE);
    I2C_Status = I2C_Accel_I2CMasterWriteByte(ACCEL_SYSMOD_REG);
    I2C_Status = I2C_Accel_I2CMasterWriteByte(ACCEL_MODE_STANDBY);
    I2C_Status = I2C_Accel_I2CMasterSendStop();
    //set the system control mode for 800 Hz sampling
    I2C_Status = I2C_Accel_I2CMasterSendStart(ACCEL_I2C_ADDR, I2C_WRITE);
    I2C_Status = I2C_Accel_I2CMasterWriteByte(ACCEL_CTRL_REG1);
    I2C_Status = I2C_Accel_I2CMasterWriteByte(ACCEL_CTRL_REG_MODE);
    I2C_Status = I2C_Accel_I2CMasterSendStop();
    //set the system mode to active
    I2C_Status = I2C_Accel_I2CMasterSendStart(ACCEL_I2C_ADDR, I2C_WRITE);
    I2C_Status = I2C_Accel_I2CMasterWriteByte(ACCEL_SYSMOD_REG);
    I2C_Status = I2C_Accel_I2CMasterWriteByte(ACCEL_MODE_WAKE);
    I2C_Status = I2C_Accel_I2CMasterSendStop();
    
    CyGlobalIntEnable; /* Uncomment this line to enable global interrupts. */
    for(;;)
    {
        uint8 accelStatus;
        uint8 accelX_MSB, accelX_LSB, accelY_MSB, accelY_LSB, accelZ_MSB, accelZ_LSB;
        int16 accelX, accelY, accelZ;
        uint16 accelXAbs, accelYAbs, accelZAbs;
        uint16 accelXAbsIIR, accelYAbsIIR, accelZAbsIIR;
        uint8 sampleIndex;
        /* Place your application code here. */
        
        /* Start the I2C register reads by writing the target register */
        I2C_Status = I2C_Accel_I2CMasterSendStart(ACCEL_I2C_ADDR, I2C_WRITE);
        I2C_Status = I2C_Accel_I2CMasterWriteByte(ACCEL_STATUS_REG);
        /* Start the register read */
        I2C_Status = I2C_Accel_I2CMasterSendRestart(ACCEL_I2C_ADDR, I2C_READ);
        /* Read out 7 bytes of status and X and Y acceleration data */
        accelStatus = I2C_Accel_I2CMasterReadByte(I2C_ACK);
        accelX_MSB = I2C_Accel_I2CMasterReadByte(I2C_ACK);
        accelX_LSB = I2C_Accel_I2CMasterReadByte(I2C_ACK);
        accelY_MSB = I2C_Accel_I2CMasterReadByte(I2C_ACK);
        accelY_LSB = I2C_Accel_I2CMasterReadByte(I2C_ACK);
        accelZ_MSB = I2C_Accel_I2CMasterReadByte(I2C_ACK);
        accelZ_LSB = I2C_Accel_I2CMasterReadByte(I2C_NACK);
        /* Send a stop condition to end the I2C transaction */
        I2C_Status = I2C_Accel_I2CMasterSendStop();
        
        /* Convert the acceleration MSBs and LSBs to signed ints */
        accelX = ((int16)((accelX_MSB<<8) + accelX_LSB))>>4;
        accelY = ((int16)((accelY_MSB<<8) + accelY_LSB))>>4;
        accelZ = ((int16)((accelZ_MSB<<8) + accelZ_LSB))>>4;
        
        /* Take absolute value of accelerations                               */
        accelXAbs = abs16(accelX);
        accelYAbs = abs16(accelY);
        accelZAbs = abs16(accelZ);
        
        /* Perform an FIR filter to smooth out the LED display data           */
        accelXAbsIIR = (accelXAbsIIR*3/4) + (accelXAbs*1/4);
        accelYAbsIIR = (accelYAbsIIR*3/4) + (accelYAbs*1/4);
        accelZAbsIIR = (accelZAbsIIR*3/4) + (accelZAbs*1/4);
        
        // Use the button as an "off" switch so users can leave spaces in lines
        if(Pin_Button_Read())
        {
            /* Set the red, green, and blue LED intensities based on X, Y, and Z  */
            LED_RGB_SetColorRGB(accelXAbsIIR<<5, accelYAbsIIR<<5, accelZAbsIIR<<5);
        }
        else
        {
            // Turn the LEDs off
            LED_RGB_SetColorRGB(0,0,0);
        }
        
        //print every 10th sample to the UART to keep traffic down
        sampleIndex++;
        if(sampleIndex>=10)
        {
            sampleIndex=0;
            /* Print the accelerometer data to the UART for reading in Bridge     *
             * Control Panel.                                                     *
             * Read with BCP command "RX8 [h=43] @STATUS @1X @0X @1Y @0Y @1Z @0Z" *
             *   X, Y, and Z should be an signed ints.                            *
             *   STATUS should be an unsigned byte                                */
            UART_Debug_UartPutChar('C'); /* Alignment character 'C' (hex 0x43) */
            UART_Debug_UartPutChar(accelStatus);
            UART_Debug_UartPutChar(accelX>>8);
            UART_Debug_UartPutChar(accelX&0xff);
            UART_Debug_UartPutChar(accelY>>8);
            UART_Debug_UartPutChar(accelY&0xff);
            UART_Debug_UartPutChar(accelZ>>8);
            UART_Debug_UartPutChar(accelZ&0xff);
        }
        
    }
}

/* [] END OF FILE */
