/*******************************************************************************
* File Name: Pin_LEDRed.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Pin_LEDRed_H) /* Pins Pin_LEDRed_H */
#define CY_PINS_Pin_LEDRed_H

#include "cytypes.h"
#include "cyfitter.h"
#include "Pin_LEDRed_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    Pin_LEDRed_Write(uint8 value) ;
void    Pin_LEDRed_SetDriveMode(uint8 mode) ;
uint8   Pin_LEDRed_ReadDataReg(void) ;
uint8   Pin_LEDRed_Read(void) ;
uint8   Pin_LEDRed_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Pin_LEDRed_DRIVE_MODE_BITS        (3)
#define Pin_LEDRed_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - Pin_LEDRed_DRIVE_MODE_BITS))
#define Pin_LEDRed_DRIVE_MODE_SHIFT       (0x00u)
#define Pin_LEDRed_DRIVE_MODE_MASK        (0x07u << Pin_LEDRed_DRIVE_MODE_SHIFT)

#define Pin_LEDRed_DM_ALG_HIZ         (0x00u << Pin_LEDRed_DRIVE_MODE_SHIFT)
#define Pin_LEDRed_DM_DIG_HIZ         (0x01u << Pin_LEDRed_DRIVE_MODE_SHIFT)
#define Pin_LEDRed_DM_RES_UP          (0x02u << Pin_LEDRed_DRIVE_MODE_SHIFT)
#define Pin_LEDRed_DM_RES_DWN         (0x03u << Pin_LEDRed_DRIVE_MODE_SHIFT)
#define Pin_LEDRed_DM_OD_LO           (0x04u << Pin_LEDRed_DRIVE_MODE_SHIFT)
#define Pin_LEDRed_DM_OD_HI           (0x05u << Pin_LEDRed_DRIVE_MODE_SHIFT)
#define Pin_LEDRed_DM_STRONG          (0x06u << Pin_LEDRed_DRIVE_MODE_SHIFT)
#define Pin_LEDRed_DM_RES_UPDWN       (0x07u << Pin_LEDRed_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define Pin_LEDRed_MASK               Pin_LEDRed__MASK
#define Pin_LEDRed_SHIFT              Pin_LEDRed__SHIFT
#define Pin_LEDRed_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Pin_LEDRed_PS                     (* (reg32 *) Pin_LEDRed__PS)
/* Port Configuration */
#define Pin_LEDRed_PC                     (* (reg32 *) Pin_LEDRed__PC)
/* Data Register */
#define Pin_LEDRed_DR                     (* (reg32 *) Pin_LEDRed__DR)
/* Input Buffer Disable Override */
#define Pin_LEDRed_INP_DIS                (* (reg32 *) Pin_LEDRed__PC2)


#if defined(Pin_LEDRed__INTSTAT)  /* Interrupt Registers */

    #define Pin_LEDRed_INTSTAT                (* (reg32 *) Pin_LEDRed__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins Pin_LEDRed_H */


/* [] END OF FILE */
