/*******************************************************************************
* File Name: Pin_Accel_GND.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Pin_Accel_GND_H) /* Pins Pin_Accel_GND_H */
#define CY_PINS_Pin_Accel_GND_H

#include "cytypes.h"
#include "cyfitter.h"
#include "Pin_Accel_GND_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    Pin_Accel_GND_Write(uint8 value) ;
void    Pin_Accel_GND_SetDriveMode(uint8 mode) ;
uint8   Pin_Accel_GND_ReadDataReg(void) ;
uint8   Pin_Accel_GND_Read(void) ;
uint8   Pin_Accel_GND_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Pin_Accel_GND_DRIVE_MODE_BITS        (3)
#define Pin_Accel_GND_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - Pin_Accel_GND_DRIVE_MODE_BITS))
#define Pin_Accel_GND_DRIVE_MODE_SHIFT       (0x00u)
#define Pin_Accel_GND_DRIVE_MODE_MASK        (0x07u << Pin_Accel_GND_DRIVE_MODE_SHIFT)

#define Pin_Accel_GND_DM_ALG_HIZ         (0x00u << Pin_Accel_GND_DRIVE_MODE_SHIFT)
#define Pin_Accel_GND_DM_DIG_HIZ         (0x01u << Pin_Accel_GND_DRIVE_MODE_SHIFT)
#define Pin_Accel_GND_DM_RES_UP          (0x02u << Pin_Accel_GND_DRIVE_MODE_SHIFT)
#define Pin_Accel_GND_DM_RES_DWN         (0x03u << Pin_Accel_GND_DRIVE_MODE_SHIFT)
#define Pin_Accel_GND_DM_OD_LO           (0x04u << Pin_Accel_GND_DRIVE_MODE_SHIFT)
#define Pin_Accel_GND_DM_OD_HI           (0x05u << Pin_Accel_GND_DRIVE_MODE_SHIFT)
#define Pin_Accel_GND_DM_STRONG          (0x06u << Pin_Accel_GND_DRIVE_MODE_SHIFT)
#define Pin_Accel_GND_DM_RES_UPDWN       (0x07u << Pin_Accel_GND_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define Pin_Accel_GND_MASK               Pin_Accel_GND__MASK
#define Pin_Accel_GND_SHIFT              Pin_Accel_GND__SHIFT
#define Pin_Accel_GND_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Pin_Accel_GND_PS                     (* (reg32 *) Pin_Accel_GND__PS)
/* Port Configuration */
#define Pin_Accel_GND_PC                     (* (reg32 *) Pin_Accel_GND__PC)
/* Data Register */
#define Pin_Accel_GND_DR                     (* (reg32 *) Pin_Accel_GND__DR)
/* Input Buffer Disable Override */
#define Pin_Accel_GND_INP_DIS                (* (reg32 *) Pin_Accel_GND__PC2)


#if defined(Pin_Accel_GND__INTSTAT)  /* Interrupt Registers */

    #define Pin_Accel_GND_INTSTAT                (* (reg32 *) Pin_Accel_GND__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins Pin_Accel_GND_H */


/* [] END OF FILE */
